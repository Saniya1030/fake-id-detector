package org.example.twitterfakeiddetector;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TwitterFakeIdDetectorApplicationTests {

    @Test
    void contextLoads() {
    }

}
