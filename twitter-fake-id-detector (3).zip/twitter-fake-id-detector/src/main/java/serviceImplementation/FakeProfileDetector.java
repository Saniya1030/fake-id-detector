package serviceImplementation;

import org.example.twitterfakeiddetector.model.TwitterProfile;

import java.time.LocalDate;

public class FakeProfileDetector {

    public static boolean isFake(TwitterProfile profile) {
        // Very simple heuristics
        if (profile.getFollowers() < 10 &&
                profile.getTweets() < 10 &&
                profile.getFollowing() > 1000) {
            return true;
        }

        // Suspicious username pattern
        if (profile.getUsername().matches(".*\\d{5,}.*")) {
            return true;
        }

        // Very new account
        LocalDate createdDate = LocalDate.parse(profile.getCreatedAt());
        if (createdDate.isAfter(LocalDate.now().minusMonths(1))) {
            return true;
        }

        return false;
    }
}

