package org.example.twitterfakeiddetector.service;

import org.example.twitterfakeiddetector.model.DetectionResult;
import org.example.twitterfakeiddetector.model.TwitterProfile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import serviceImplementation.FakeProfileDetector;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;


import org.springframework.http.*;


@Service
public class TwitterDetectionService {

    @Autowired
    private RestTemplate restTemplate;


    private static final String BEARER_TOKEN =
            "Bearer AAAAAAAAAAAAAAAAAAAAAC5e0gEAAAAAbkThHwKkTD7sSadzagbzO7kkAA8%3DFtf5lCZxmuYKYjf5c3Si90Eesr2to6WuYKqES8j18n2XXFhncQ";

    public DetectionResult detectProfile(String username) {
        // 1. Call Twitter API (mocked here)
        TwitterProfile profile = fetchProfileFromTwitter(username);

        // 2. Run detection logic
        boolean isFake = FakeProfileDetector.isFake(profile);

        return new DetectionResult(username, isFake, profile);
    }

    private TwitterProfile fetchProfileFromTwitter(String username) {
        try {
            String url = "https://api.twitter.com/2/users/by/username/" + username + "?user.fields=public_metrics,created_at";

            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", BEARER_TOKEN);

            HttpEntity<String> entity = new HttpEntity<>(headers);
            ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);

            if (response.getStatusCode() == HttpStatus.OK) {
                String responseBody = response.getBody();
                ObjectMapper mapper = new ObjectMapper();
                JsonNode root = mapper.readTree(responseBody);
                JsonNode user = root.path("data");

                String uname = user.path("username").asText();
                String name = user.path("name").asText();
                String createdAt = user.path("created_at").asText().substring(0, 10); // yyyy-MM-dd

                JsonNode metrics = user.path("public_metrics");
                int followers = metrics.path("followers_count").asInt();
                int following = metrics.path("following_count").asInt();
                int tweets = metrics.path("tweet_count").asInt();

                return new TwitterProfile(uname, followers, tweets, following, createdAt, name);
            }

            // Handle non-200 responses
            throw new RuntimeException("Failed to fetch profile from Twitter API");

        } catch (Exception e) {
            throw new RuntimeException("Twitter API error: " + e.getMessage(), e);
        }
    }
}
