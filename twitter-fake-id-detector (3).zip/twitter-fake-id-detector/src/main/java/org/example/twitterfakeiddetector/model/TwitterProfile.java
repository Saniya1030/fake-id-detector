package org.example.twitterfakeiddetector.model;

public class TwitterProfile {
    private String username;
    private int followers;
    private int tweets;
    private int following;
    private String createdAt;
    private String name;

    public TwitterProfile() {
    }

    public TwitterProfile(String username, int followers, int tweets, int following, String createdAt, String name) {
        this.username = username;
        this.followers = followers;
        this.tweets = tweets;
        this.following = following;
        this.createdAt = createdAt;
        this.name = name;
    }

    // Getters and Setters
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getFollowers() {
        return followers;
    }

    public void setFollowers(int followers) {
        this.followers = followers;
    }

    public int getTweets() {
        return tweets;
    }

    public void setTweets(int tweets) {
        this.tweets = tweets;
    }

    public int getFollowing() {
        return following;
    }

    public void setFollowing(int following) {
        this.following = following;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}


