package org.example.twitterfakeiddetector.model;

public class DetectionResult {
    private String username;
    private boolean isFake;
    private TwitterProfile profile;

    public DetectionResult() {
    }

    public DetectionResult(String username, boolean isFake, TwitterProfile profile) {
        this.username = username;
        this.isFake = isFake;
        this.profile = profile;
    }

    // Getters and Setters
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public boolean isFake() {
        return isFake;
    }

    public void setFake(boolean fake) {
        isFake = fake;
    }

    public TwitterProfile getProfile() {
        return profile;
    }

    public void setProfile(TwitterProfile profile) {
        this.profile = profile;
    }
}


