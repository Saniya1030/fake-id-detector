package org.example.twitterfakeiddetector.controller;

import org.example.twitterfakeiddetector.model.DetectionResult;
import org.example.twitterfakeiddetector.service.TwitterDetectionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/twitter")
public class TwitterDetectionController {

    @Autowired
    private TwitterDetectionService detectionService;

    @GetMapping("/detect")
    public DetectionResult detectFakeProfile(@RequestParam String username) {
        return detectionService.detectProfile(username);
    }
}
